﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using NoteMVVM;
using test_1_semester_projekt.Annotations;


namespace test_1_semester_projekt 
{
    class JobModelView : INotifyPropertyChanged
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Tlf { get; set; }

        public ObservableCollection<JobModel> JobList { get; set; }

        public ICommand AddCommand { get; set; }
        

        public JobModelView()
        {
            JobList = new ObservableCollection<JobModel>()
            {
                new JobModel("Kurt", "Hejrevej 11", "25 45 45 85")
            };
            AddCommand = new RelayCommand(Add);
            

        }

        public void Add()
        {
            JobList.Add(new JobModel(Name , Address, Tlf));

        }


        


        #region MyRegion
        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        } 
        #endregion
    }
}
