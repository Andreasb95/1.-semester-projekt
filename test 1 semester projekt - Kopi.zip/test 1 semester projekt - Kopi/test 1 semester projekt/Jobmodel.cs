﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_1_semester_projekt
{
    class JobModel
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Tlf { get; set; }

        public JobModel(string name, string address, string tlf)
        {
            Name = name;
            Address = address;
            Tlf = tlf;
        }

        public override string ToString()
        {
            return $" {Name} \n {Address} \n {Tlf} ";
        }

        
    }
}
