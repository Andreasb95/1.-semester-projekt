﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Runtime.InteropServices;
using System.Text;

namespace ConsoleApp2
{
    class Student
    {
        private int _age1;
        public string _name;
        public int _tlf; 

        public int _age
        {
            get => _age1;
            set => _age1 = value;
        }

        

        public Student(int age1, string name, int tlf)
        {
            _age1 = age1;
            _name = name;
            _tlf = tlf;
            
        }

       
        public void print()
        {
            Console.WriteLine($"Navn {_name}");

        }


        
        
        

    }
}
