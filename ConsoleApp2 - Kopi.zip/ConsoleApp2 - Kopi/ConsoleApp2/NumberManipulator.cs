﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class NumberManipulator
    {

            public int FindMax(int num1, int num2)
            {
                /* local variable declaration */
                int result;

                if (num1 > num2)
                    result = num1;
                else
                    result = num2;

                return result;
            }
            
    }

    
}
