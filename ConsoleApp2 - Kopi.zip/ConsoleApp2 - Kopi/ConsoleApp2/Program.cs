﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");

            //Student student1 = new Student("Henrik", 88888888,10);

            //int b = 1;

            //Console.WriteLine(b);


            //while (b<5)
            //{
            //    b++;
            //}


            //for (int i = 1; i <= 8; i++)
            //{
            //    Console.WriteLine(i);
                
            //}

            //Console.WriteLine(b);

            //for (int i = 0; i < 10; i++)
            //{
            //    if (i == 4)
            //    {
            //        break;
            //    }
            //    Console.WriteLine(i);
            //}




            //student1.print();



            //student1._age = 8;

            //bool teenager;

            //if (student1._age >= 10)
            //{
            //    teenager = true;} 
            //else {teenager = false;}
            //Console.WriteLine($"Han er teenager {teenager}");

            //int c = 0;

            //////while (true)
            //////{
            //////    Console.WriteLine(c);
            //////    c++;

            //////}


            //int[] Array = new int[] {1, 2, 3};

            //foreach (int Tal in Array)
            //{
            //    Console.WriteLine(Tal);
            //}

            //Console.WriteLine(Array);

            int age = 22;

            if (age <= 22)
            {
                Console.WriteLine(age);
            }
            else
            {
                Console.WriteLine("Du er en stor knæææææææææægt");
            }


            string[] cars = {"bmw"};

            int [] myray = new int[10];

            myray[0] = 1;

            int [] newray = new int[] {1,2,3,4};

            foreach (var tal in newray)
            {
                Console.WriteLine(tal);
            }
        
           

            List<string> listOfStrings = new List<string>();
            listOfStrings.Add("Oliver");

            foreach (string lort in listOfStrings)
            {
                Console.WriteLine(lort);
            }


            Student student1 = new Student(12,"kasper",8888888);
            Student student200 = new Student(123, "tasper", 88);


            Dictionary<int,String> students = new Dictionary<int, string>();
            students.Add(1,"student1");
            students.Add(27,"student200");

            Console.WriteLine(students[27]); //dette er et direkte opslag


            //foreach (var dic in students)
            {
                //Console.WriteLine("key: {0}, value: {1}", dic.Key, dic.Value);
                // key value er på index 0 plads derfor i CW står der 0 ved key: for at udskrive key  (samme princip med value på index 1)
                //Console.WriteLine(students[27]);
            }


            ////string messeage = "string";

            ////int taaaal = 5;

            ////int taallll = new int ();

            ////taallll = 4;
            ///
           // string addstr(string s1, string s2, string s3)
          //  {

           //     string result = s1 + s2 + s3;
            //    return result;
                
          //  }


            

            
            
            NumberManipulator Kasper = new NumberManipulator();

           ////int numb2 = 2;

            //Kasper.FindMax(5, 2);

            Console.WriteLine(Kasper.FindMax(5,2));


            for (int f = 0; f <= 10; f++)
            {
                
                
                if (f == 2)
                {
                    break;
                }

                Console.WriteLine(f);
            }
            
            











        }
    }
}
